# Analiza los servidores que inician tus clientes MCP

> 🌐 [English](scan.md) · [Русский](scan.ru.md) · **Español** · [Français](scan.fr.md) · [中文](scan.zh.md)

Las llamadas de descubrimiento pueden generar cargos; consulte los [límites de medición y pruebas de versión](scan-limits.es.md) antes de interpretar un scan o confiar en una versión declarada.

`warden-mcp scan` lee la configuración MCP que ya tienes, se conecta a cada servidor que inicia y revisa las definiciones de herramientas antes de que un modelo las vea. Es la misma cadena de compuertas que [`wrap`](../README-es.md) y la [biblioteca](integration.es.md), ejecutada una vez sobre tus configuraciones en lugar de delante de un solo servidor.

```bash
npx -y @aimarket/warden@0.38.0 scan
```

```text
WARDEN scan 0.29.0 · ruleset 23 sha256-J12lNmUUNTNk… · malware list 2026-11-17 · block at high
  read .mcp.json (claude-code, 3 servers)

  ✓ allow   notes       claude-code    1 tool · score 0.90
  ✗ BLOCK   evil-notes  claude-code    1 tool · score 0.00 · TOOL_DEF_EXFIL(save_note) TOOL_DEF_SECRET_REQUEST(save_note) THREAT_SSH_KEY_READ(save_note) THREAT_SEED_PHRASE(save_note)
  ! error   broken      claude-code    could not start: spawn /nonexistent/bin/server ENOENT

3 servers: 1 allowed, 1 blocked, 1 not checked, 0 skipped.
Details: warden-mcp scan --json, or --markdown FILE. To review a changed server: warden-mcp scan --lock warden.lock.json --update-lock.
```

Sin cuenta, sin clave de API, sin modelo. El único tráfico de red va a los servidores de tu configuración y, si pasas `--histor`, al registro HISTOR. Sin esa opción el escaneo termina con una línea: cuántos de tus servidores son públicos (un paquete de npm o PyPI, o una dirección pública) y por tanto podrían compararse con el registro. Ese recuento se hace en tu máquina y no se envía nada.

## Dónde busca

Sin argumentos, cada archivo de la tabla que exista. Pasa archivos para analizar solo esos, `--project` para los archivos del proyecto en el directorio de trabajo, o `--client NAME` para un solo cliente.

| Cliente | Archivo del proyecto | Archivo del usuario |
|---|---|---|
| Claude Code | `.mcp.json` | `~/.claude.json` (servidores del usuario y de este proyecto) |
| Claude Desktop | — | `claude_desktop_config.json` en el directorio de configuración de la aplicación |
| Cursor | `.cursor/mcp.json` | `~/.cursor/mcp.json` |
| VS Code | `.vscode/mcp.json` (JSONC) | `mcp.json` en el directorio de ajustes del usuario |
| Windsurf | — | `~/.codeium/windsurf/mcp_config.json` |

Un servidor que la configuración inicia mediante `warden-mcp wrap` se analiza como el servidor que hay detrás del envoltorio, con el id de pin que usa `wrap`, de modo que la deriva respecto de la instantánea aprobada aparece en el informe. Las entradas desactivadas, las que necesitan un valor `${input:…}` que el cliente pide al usuario y las que no tienen ni `command` ni `url` se listan como omitidas; nunca desaparecen en silencio.

## Iniciar servidores

Para leer las herramientas de un servidor stdio, `scan` lo inicia con el comando, los argumentos y el entorno de la configuración, igual que lo haría tu cliente, y lo detiene después de `tools/list`. Nunca llama a una herramienta. Aun así, el programa se ejecuta. Donde no lo quieras, por ejemplo en CI sobre un pull request, `--no-launch` revisa solo la línea de arranque: los registros de comandos del threat feed y la identidad de arranque del lock.

Antes de iniciar un servidor que un gestor de paquetes descarga de npm o PyPI (`npx`, `uvx` y similares), `scan` busca el paquete en la lista de paquetes maliciosos conocidos que viene con WARDEN ([malware-list](gates.es.md#malware-list)). Un paquete que OpenSSF lista como malware, en todas sus versiones o en la versión que fija la línea de arranque, se bloquea y nunca se inicia; `--no-launch` también lo comprueba. La cabecera del informe indica la fecha de la lista.

Los servidores remotos (`url`, streamable HTTP o el antiguo HTTP+SSE) se consultan por la red con las cabeceras de la configuración. `--public-only` rechaza los que se resuelven a direcciones loopback, privadas, link-local o de metadatos de la nube, comprobando la dirección a la que realmente se conecta. No se siguen redirecciones.

## Salida y códigos de salida

| Opción | Escribe |
|---|---|
| (por defecto) | una tabla en stdout |
| `--json` | el informe JSON en stdout |
| `--json-file FILE` | el informe JSON en un archivo, junto con la tabla |
| `--sarif FILE` | SARIF 2.1.0 para GitHub code scanning; solo hallazgos que bloquean, ubicados en la línea del servidor en la configuración |
| `--markdown FILE` | un resumen con detalles plegables, para `$GITHUB_STEP_SUMMARY` o un comentario en el PR |

Código `0`: nada bloqueado. `1`: se bloqueó un servidor o, con `--fail-on-error`, no se pudo comprobar. `2`: error de uso o de configuración. `--fail-on SEVERITY` mueve el umbral de bloqueo; `--policy FILE` acepta el mismo archivo de política estricto que `wrap`.

Las credenciales en líneas de arranque y URL se muestran como `***`. Las descripciones de herramientas del informe Markdown van dentro de bloques de código que ese texto no puede cerrar.

## El archivo lock: revisa las definiciones, no solo el comando

Una línea de configuración dice qué programa arranca. No dice qué le contará ese programa a tu modelo. El lock registra lo segundo, para que un pull request lo muestre.

```bash
warden-mcp scan --project --lock warden.lock.json --update-lock   # después de leer qué cambió
git add .mcp.json warden.lock.json
```

`--update-lock` escribe la identidad de arranque de cada servidor y sus definiciones completas, y se niega a registrar un servidor que WARDEN bloquea. Volver a ejecutarlo sobre servidores sin cambios no modifica el archivo. Solo con `--lock`:

- un servidor que el lock no conoce se bloquea (`LOCK_MISSING`);
- un servidor que arranca de otra forma se bloquea (`SERVER_IDENTITY_DRIFT`);
- un servidor que ahora anuncia otras herramientas se bloquea (`TOOL_DEF_DRIFT`), y el informe Markdown muestra el cambio como un diff de nombres, descripciones y esquemas.

Las entradas del lock que ninguna configuración inicia se listan y se eliminan en la siguiente actualización.

## GitHub Action

```yaml
name: MCP servers
on: [pull_request]
permissions:
  contents: read
  security-events: write   # solo para upload-sarif
jobs:
  warden:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: alexar76/warden@v0.31.0
        with:
          upload-sarif: 'true'
```

Por defecto lee los archivos del proyecto, no inicia servidores stdio (ese programa lo elige el pull request), rechaza direcciones no públicas, usa `warden.lock.json` si existe, escribe el resumen del job y falla ante un servidor bloqueado. Entradas: `config`, `working-directory`, `lock`, `launch-stdio`, `public-only`, `fail-on`, `histor`, `classifier-url`, `classifier-model`, `classifier-blocks`, `sarif`, `upload-sarif`, `version`. Salidas: `blocked`, `servers`, `sarif`. En workflows de producción, fija la acción por SHA de commit.

Para enterarte de cuándo cambia un servidor que usas, ejecuta también el mismo job con un horario (`on: { schedule: [{ cron: '17 6 * * *' }] }`): con un `warden.lock.json` en el repositorio, un servidor cuyas definiciones de herramientas cambiaron hace fallar la ejecución con `TOOL_DEF_DRIFT` y el resumen muestra el diff.

## pre-commit

```yaml
repos:
  - repo: https://github.com/alexar76/warden
    rev: v0.10.0
    hooks:
      - id: warden-scan     # configuraciones modificadas; no inicia servidores stdio
      - id: warden-lock     # el proyecto coincide con warden.lock.json; inicia servidores stdio
```

Ambos ejecutan el paquete publicado mediante `npx`, así que necesitas Node 20 o posterior en el `PATH`.

## Plugin de Claude Code

```text
/plugin marketplace add alexar76/warden
/plugin install warden@warden
```

Al iniciar la sesión analiza los servidores que Claude Code inicia para el proyecto, te dice cuáles están bloqueados y al modelo solo le da el nombre y el código del hallazgo. Una descripción bloqueada nunca entra en el contexto del modelo. Después, un hook `PreToolUse` deniega las llamadas a herramientas de un servidor bloqueado o a una herramienta bloqueada; lee un archivo pequeño y no inicia nada. Detalles y límites: [claude-plugin/README.md](../claude-plugin/README.md).

## Flujos tóxicos: seguros uno a uno, peligrosos juntos

Un cliente entrega las herramientas de todos sus servidores a un mismo modelo. Si entre ellos hay una herramienta que lee tus datos privados, otra por la que entra texto de fuera (una página web, una issue, un correo) y otra que puede enviar datos fuera, el texto que llega por la segunda puede pedirle al modelo que lea con la primera y envíe con la tercera. Ningún servidor tiene la culpa, así que ningún veredicto por servidor lo muestra. `scan` lo informa por cliente:

```text
  ⚠ toxic flow  claude-code can read private data (filesystem.read_file, …), take in text from outside (fetch.fetch) and send data out (fetch.fetch). …
```

Las capacidades se leen de los nombres de las herramientas y de sus parámetros (`read_file`, `send_email`, un parámetro `url` o `to`), no de las descripciones: no depende del idioma, y una descripción no puede justificarse. Un flujo es orientativo: nunca bloquea ni cambia el código de salida. Aparece en `--json` (`flows`) y en el resumen Markdown. Para romperlo, quita una pata: un servidor `fetch` que no necesitas, o un servidor de archivos limitado a una carpeta en otro cliente.

## Una indicación que contradice la propia descripción de la herramienta

Un lock guarda una indicación de comportamiento equivocada tan estable como una correcta: dice si el servidor cambió su versión, no si era verdad. Una parte se ve en la propia definición. `scan` informa `TOOL_HINT_CONTRADICTS_DESCRIPTION` cuando una herramienta dice `readOnlyHint: true` y su descripción dice que borra, envía un mensaje, escribe archivos o crea una cuenta, o dice `destructiveHint: false` y su descripción dice que elimina, sobrescribe, "replaces the current …" o "cannot be undone":

```text
  ⚠ hint vs description  github.update_issue_labels: The server marks this tool destructiveHint=false, but its own description says it replaces the current …: "This replaces the current labels with the provided list." …
```

Es consultivo, como un flujo tóxico: aparece en la salida, en el informe Markdown y en `--json` (no en SARIF), nunca bloquea ni cambia el código de salida. Un cliente que no pide aprobación para herramientas de solo lectura o no destructivas no preguntaría antes de esa llamada, así que etiquete la herramienta usted mismo (`labels` de la política de flujos). La lectura es en inglés, frase por frase, y solo donde la herramienta es el sujeto del verbo ("Deletes the file", no "List deleted files"); las reglas se calibraron con las definiciones de herramientas de HISTOR (ver el CHANGELOG). Una indicación que solo el código contradice no se ve.

En `--json` cada uno de estos hallazgos lleva además `evidence`: `claim` (la indicación que pone el servidor, por ejemplo `destructiveHint=false`), `matchedPhrase` (las palabras de la descripción que la contradicen, en minúsculas) y `quotedSentence` (la frase completa; el mensaje cita sus primeros 160 caracteres). Así puede agrupar los hallazgos por la palabra que los activó, o comparar dos ejecuciones, sin analizar el mensaje:

```bash
warden-mcp scan --json | jq -r '.servers[].findings[] | select(.code == "TOOL_HINT_CONTRADICTS_DESCRIPTION") | [.evidence.matchedPhrase, .tool, .evidence.quotedSentence] | @tsv'
```

## HISTOR: ¿este servidor te sirve lo mismo que a todos?

[HISTOR](https://histor.modelmarket.dev) es un registro público que anota cada día las definiciones de herramientas de todos los servidores remotos del registro oficial de MCP. `--histor` le hace una pregunta por cada servidor remoto: ¿el conjunto de herramientas que te acaban de servir es el que observa HISTOR?

Qué se envía: el endpoint, solo esquema, host y ruta (sin query, sin usuario ni contraseña), y el digest [MTL/1](https://github.com/alexar76/awr) del conjunto de herramientas. Ninguna descripción de herramienta, ninguna cabecera suya. El User-Agent es `warden-scan/<versión>`, seguido de `(ci)` cuando el escaneo corre en CI (`(ci; github-actions)`, `(ci; gitlab)`) para que HISTOR pueda contar las comprobaciones que se repiten en cada build; nunca nombra el repositorio ni el runner. Los endpoints en hosts o direcciones privadas, y las rutas que parecen llevar una clave, no se envían; el informe dice por qué.

Un servidor stdio que arranca desde el registro público de npm o PyPI (`npx`, `bunx`, `npm exec`, `pnpm dlx`, `uvx`, `uv tool run`, `pipx run`) se identifica por su paquete —`npm:<nombre>` o `pypi:<nombre>`, sin la versión— y el mismo digest. HISTOR instala cada versión publicada de ese paquete en un sandbox gVisor (credenciales señuelo, sin ruta hacia fuera; cada herramienta llamada una vez con argumentos canario, sin actuar sobre nada real) y anota sus herramientas y lo que hizo; así, `previously-observed` significa aquí que ejecutas una versión más antigua, y `different`, una versión a la que HISTOR aún no ha llegado, un paquete cuyas herramientas dependen de lo que tiene tu máquina y no el sandbox (un lanzador que cede el control a un programa instalado localmente, una clave o un ajuste reales) o un paquete que no es el publicado. El hallazgo da el número de herramientas de cada lado. Una ruta local, una URL de git o de tarball, un registro privado (`--registry`, `--index-url`) o un arranque simple con `node`/`python` nunca se envían. Para un paquete, HISTOR también indica, como hallazgos orientativos, si su nombre imita a uno popular (`HISTOR_PACKAGE_LOOKALIKE`: a un carácter, el mismo nombre bajo otro scope u otros separadores, frente a un paquete descargado al menos 100 veces más) y si la versión observada tiene las marcas de un token de publicación robado: `HISTOR_PACKAGE_PROVENANCE_LOST` (sin compilación atestiguada en CI cuando la versión anterior la tenía), `HISTOR_PACKAGE_INSTALL_SCRIPTS` (nuevos scripts de instalación), `HISTOR_PACKAGE_PUBLISHER_CHANGED`, `HISTOR_PACKAGE_NEW_DEPENDENCIES`. Y lo que hizo el paquete en el sandbox: `HISTOR_PACKAGE_READS_SECRETS` (abrió credenciales señuelo —claves SSH, tokens de nube o de registros, una wallet— al instalarse, al arrancar o al llamar a una herramienta), `HISTOR_PACKAGE_PERSISTENCE` (escribió donde sobreviviría a la sesión, como `.bashrc` o `authorized_keys`), `HISTOR_PACKAGE_STARTUP_NETWORK` (salió a la red antes de que se llamara a ninguna herramienta), `HISTOR_PACKAGE_STARTS_PROGRAMS`, `HISTOR_PACKAGE_INSTALL_BEHAVIOUR` (lo que hacen sus scripts de instalación). Cargar `.env` del directorio de trabajo y llamar a su propia API durante una llamada no son hallazgos. Por qué un paquete no arrancó, según lo que imprimió: `HISTOR_PACKAGE_SDK_INCOMPATIBLE` (medium — escrito para MCP SDK 1.x, así que una instalación nueva con `mcp` 2.x falla al importar; si HISTOR también lo ejecutó con `mcp<2`, cuántas herramientas listó entonces), `HISTOR_PACKAGE_NEEDS_CONFIG` (info — la clave o ajuste que pidió, o que sus herramientas se leyeron con valores de relleno) y `HISTOR_PACKAGE_KEY_SENT_TO` (low — adónde envió la clave de relleno de HISTOR; compruebe que es la API del propio servicio). Todos los hallazgos del sandbox salen de las mismas condiciones: Linux bajo gVisor, sin internet, secretos señuelo ([condiciones de prueba](https://histor.modelmarket.dev/#conditions)). Con `--histor`, el informe también da un enlace a un feed de HISTOR con los cambios de los servidores escaneados que HISTOR conoce (`historWatch` en `--json`): suscríbete en cualquier lector de feeds.

| Respuesta | Significado |
|---|---|
| `same` | Te sirvieron el conjunto que HISTOR observa ahora |
| `different` | HISTOR nunca vio este conjunto: cambió después del último rastreo diario, o el servidor te sirve algo que no sirve al rastreador público. Para un paquete, también: sus herramientas dependen de lo que tiene tu máquina (ver arriba). Se informa como hallazgo consultivo `HISTOR_UNSEEN_TOOLSET` |
| `previously-observed` | Un conjunto que HISTOR vio antes, no el actual. Hallazgo consultivo `HISTOR_OLDER_TOOLSET` |
| `not-listed`, `not-observed` | HISTOR no conoce este endpoint o todavía no lo ha leído con éxito |

Si el conjunto que recibiste es uno que el editor del servidor declara en su entrada del registro ([cómo declara un editor un conjunto](https://github.com/alexar76/histor/blob/main/docs/api.es.md)), por ejemplo las herramientas de un lanzador donde su programa está instalado, el hallazgo es `HISTOR_DECLARED_TOOLSET` en lugar de `HISTOR_UNSEEN_TOOLSET`: low, o info cuando HISTOR no tiene un conjunto propio, con la condición del editor en sus palabras. Es la palabra del editor, no una observación, y todas las demás comprobaciones siguen leyendo las herramientas.

Las respuestas de HISTOR nunca bloquean. Si HISTOR no responde, se informa y el análisis continúa.

## Para editores: declara los conjuntos de herramientas de tu servidor

HISTOR solo puede registrar las herramientas que tu servidor lista en su sandbox. Si lista otras donde está instalado algo que el sandbox no tiene —el runner de un lanzador, uno por sistema operativo, una clave real—, declara esos conjuntos, y quienes los reciben verán `HISTOR_DECLARED_TOOLSET` (low) en lugar de `HISTOR_UNSEEN_TOOLSET` (medium). En una máquina que recibe el conjunto:

```bash
npx -y @aimarket/warden declare --when "runner 1.4, macOS" --out mcp-tool-sets.json -- npx -y @acme/launcher
```

WARDEN arranca el servidor como lo haría un cliente, calcula el digest de su `tools/list` (MTL/1) y añade el conjunto a `mcp-tool-sets.json`, conservando los que ya había y reemplazando el mismo digest. Repítelo en cada sistema operativo y versión del runner. Después:

1. Publica el archivo en el dominio que el registro verificó para el espacio de nombres de tu servidor —`ai.acme/launcher` → `acme.ai` o un subdominio; `io.github.<user>/…` → `<user>.github.io` o tus archivos raw de GitHub—, por ejemplo en `https://acme.ai/.well-known/mcp-tool-sets.json`.
2. Apunta a él desde tu entrada del registro, una vez: `npx -y @aimarket/warden declare --server-json --link <url>` imprime el bloque `_meta` para `server.json`; publica esa versión en el registro.
3. Compruébalo: `npx -y @aimarket/warden declare --check <url> --name ai.acme/launcher` lee el archivo como lo leerá HISTOR y dice qué tomará de él.

A partir de ahí, una nueva versión del runner solo necesita `declare --out` y volver a subir el archivo: HISTOR lo lee cada hora. Un conjunto que quitas del archivo se retira; un archivo que HISTOR no puede leer conserva lo que declaró. Sin archivo, `--server-json` con el servidor después de `--` pone el conjunto en la propia entrada, hasta 8 conjuntos. Las reglas que aplica HISTOR: [declarar conjuntos](https://github.com/alexar76/histor/blob/main/docs/api.es.md). Una declaración es la palabra del editor, no una observación: WARDEN sigue ejecutando todas las comprobaciones sobre las herramientas que recibe.

## El clasificador opcional

Las reglas de WARDEN funcionan sin conexión y de forma determinista, y no ven lo que ninguna regla nombra: una paráfrasis, una instrucción en otro idioma. `--classifier-url` y `--classifier-model` añaden una segunda opinión de un modelo que tú eliges, mediante cualquier endpoint compatible con OpenAI: Ollama, vLLM o LM Studio en local, o una API alojada.

```bash
warden-mcp scan --classifier-url http://localhost:11434/v1 --classifier-model qwen2.5:14b
WARDEN_CLASSIFIER_API_KEY=… warden-mcp scan --classifier-url https://api.deepseek.com --classifier-model deepseek-flash --classifier-reasoning-effort none
```

- **Optativo; envía todos los campos publicados.** Nombre, título, descripción, esquemas, anotaciones y extensiones, con una lectura normalizada cuando procede. La clave solo viene de `WARDEN_CLASSIFIER_API_KEY`.
- **Consultivo por defecto; cierre seguro con `--classifier-blocks`.** Los hallazgos usan `TOOL_DEF_CLASSIFIER`. Truncamiento, incertidumbre, cobertura incompleta, respuestas inválidas, errores y tiempos de espera producen `CLASSIFIER_INCOMPLETE`: son fallos de inspección, no ataques detectados. `--update-lock` no puede aprobarlos.
- **Cinco categorías.** `instruction_to_model`, `exfiltration`, `secret_request`, `concealment`, `cross_tool`. Se inspecciona la autoridad de las instrucciones en cualquier idioma; la capacidad del modelo varía. El protocolo exige una decisión por herramienta y referencias a campos verificadas por WARDEN, que extrae el texto original. Cada decisión incompleta se reintenta una sola vez de forma aislada. Los delimitadores aleatorios no garantizan inmunidad.
- **Inspección no es aprobación.** [`wrap --require-approval`](security-hardening-language-boundary.md) exige una aprobación del operador independiente del idioma. HISTOR conserva sus resultados históricos como recomendaciones.

Medido el 16 de octubre de 2026 con `deepseek-flash`, el modelo que usa HISTOR, sobre MCPTox (el benchmark publicado que se describe en la comparación de abajo), sobre servidores reales y sobre nuestros conjuntos:

| | Reglas (v12) | Reglas + clasificador en `high` |
|---|---|---|
| Mitad reservada de MCPTox, detectadas de 218 herramientas envenenadas | 171 | 218 |
| 45 servidores limpios de MCPTox, marcados | 0 | 0 |
| 200 servidores del corpus elegidos al azar, bloqueados o marcados | 2 | 5 |
| 996 paquetes de npm y PyPI de una muestra aleatoria, bloqueados o marcados | 23 | 35 |
| 23 ataques escritos por nosotros / 12 casos benignos difíciles | 20 / 0 | 23 / 0 |

Los dos servidores del corpus que bloquean las reglas son el servicio de identidad y la herramienta de despliegue de la comparación de abajo. Las marcas `high` del clasificador en servidores reales son sobre todo órdenes de flujo de trabajo como «llama primero a esta herramienta». Dos paquetes merecen una mirada humana y las reglas no bloquean ninguno: uno envuelve su descripción en un bloque falso de «el usuario lo pidió» y ordena al modelo llamarlo antes de cualquier respuesta; otro envía contenido de archivos del agente a su servidor con «Do NOT display … to the user». El modelo no vio lo que detectan las reglas: una inyección en el nombre de una herramienta, una clave privada o frase semilla pedida como parámetro y `rm -rf ~`. Juntos detectan los 23 ataques nuestros.

## Cómo se compara

El 16 de octubre de 2026 ejecutamos WARDEN, mcp-audit 0.18.2 (`--connect`), mcp-shield 1.0.4, truecopy 0.10.4 y mcpsentry 0.1.5 sobre los mismos servidores. Cada servidor se reprodujo por stdio, así que cada escáner se conectó a él como lo haría en la práctica. Cada escáner corrió en un contenedor gVisor sin red, desde imágenes fijas cuyo contenido está resumido con hashes en un manifiesto. El banco de pruebas, los conjuntos, el manifiesto y cada juicio están en [`scripts/scanner-comparison`](../scripts/scanner-comparison/). El informe completo, con el método y cada salvedad, es la [comparación de escáneres](scanner-comparison.es.md).

Las filas de MCPTox vienen de MCPTox (Wang et al., AAAI 2026), un benchmark publicado de 485 herramientas envenenadas escritas para 45 servidores MCP reales. Dividimos sus servidores en dos con un hash fijo. Las reglas v10 se escribieron con 22 servidores; la tabla informa de los otros 23, con 218 herramientas envenenadas a las que no se ajustó ninguna regla. v11 y v12 tampoco se escribieron con ellas y dan los mismos veredictos que v10.

| Servidores | WARDEN 0.16.0 (v12) | mcp-audit 0.18.2 | mcp-shield 1.0.4 | truecopy 0.10.4 | mcpsentry 0.1.5 |
|---|---|---|---|---|---|
| 23 ataques escritos por nosotros, bloqueados | 20 | 10 | 6 | 8 | 4 |
| 10 ataques de los propios fixtures de mcp-audit y mcp-shield, bloqueados | 10 | 10 | 8 | 7 | 5 |
| 12 casos benignos difíciles, bloqueados | 0 | 1 | 1 | 1 | 2 |
| 218 herramientas envenenadas de MCPTox en los servidores reservados, bloqueadas | 171 | 25 | 41 | 27 | 8 |
| 225 herramientas de MCPTox con un prefijo `<IMPORTANT>` o «Ignore the previous instructions», bloqueadas | 225 | 222 | 41 | 141 | 136 |
| 45 servidores limpios de MCPTox, bloqueados | 0 | 2 | 3 | 0 | 1 |
| 986 servidores públicos, bloqueados | 3 | 33 | 343 | 39 | 86 |
| …bloqueos que se sostienen al leer el texto | 1, y 1 discutible | 0 | 1 de los 34 que leímos | 1 | 0 |
| 14 933 paquetes de npm y PyPI que observó HISTOR, bloqueados | 369 | 928 | 5354 | 252 | 1449 |

- **Lee primero las filas de servidores reales.** Ninguna regla se ajustó a ellas. Los 33 bloqueos de mcp-audit en el corpus son sobre todo «homoglifos» en texto escrito entero en su propio alfabeto e instrucciones de honestidad como «do not tell the user the check digits are wrong». mcp-shield bloquea un tercio de los servidores reales, casi siempre por una palabra clave: «API key», «token», `.env`, «..». truecopy bloquea los generadores de docker-compose de un mismo proveedor porque producen un `.env.example`. El patrón base64 de mcpsentry coincide con cualquier secuencia de 40 letras y barras, como las que producen las rutas de JSON Schema. En 14 933 paquetes de npm y PyPI, una muestra aleatoria de 996 en la que juzgamos cada bloqueo tiene 23 bloqueos de WARDEN, ninguno se sostiene y 4 son discutibles; mcp-shield bloquea 339 de esos mismos paquetes y mcpsentry 112.
- **Ten claro qué números están ajustados.** Escribimos el primer conjunto de ataques, y las reglas v9 se escribieron después de leer ambos conjuntos de ataques. La fila de la mitad reservada de MCPTox, los servidores limpios, el corpus y los paquetes no están ajustados.
- **MCPTox prueba una forma, no una palabra clave.** Casi todas las herramientas envenenadas le dicen al modelo que llame antes a otra herramienta o que cambie los argumentos de otra. v10 le dio nombre a esa forma (`TOOL_DEF_CROSS_TOOL`, véase [la cadena de compuertas](gates.es.md)) y v12 la conserva. Con el prefijo `<IMPORTANT>` del benchmark, la mayoría de los escáneres detecta la mayoría de las herramientas.
- **Lo que WARDEN todavía no detecta:** 47 de las 218 herramientas reservadas de MCPTox, una instrucción en chino para leer `.env`, una paráfrasis sin palabras clave («gather every credential file … keep this step to yourself») y «include the output of env». Informa 41 de esas 47 como avisos, no como bloqueos. Con el clasificador opcional de arriba, las 218 quedan marcadas en `high`.
- **WARDEN no está solo en ese hueco.** mcp-audit también tiene archivo lock, modo diff para PR y SARIF; truecopy también fija y firma definiciones en un archivo lock.

## Lo que scan no hace

- Lee las definiciones una vez. Un servidor que cambie después lo detecta el siguiente análisis, el lock en CI o `wrap` en cada llamada.
- No analiza argumentos ni resultados de llamadas, prompts ni resources, y no es un sandbox: iniciar un servidor stdio lo ejecuta.
- Sus veredictos son las reglas estáticas y los registros de amenazas de WARDEN. Una paráfrasis que ninguna regla cubre pasa; consulta [la cadena de compuertas](gates.es.md) y el [estudio de campo](mcp-survey.es.md) para ver qué detectan las reglas y con qué frecuencia se equivocan.
